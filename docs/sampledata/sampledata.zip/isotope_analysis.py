from gcmstools.datastore import GcmsStore
from gcmstools.isotope import Isotope

h5 = GcmsStore('data.h5')

iso = Isotope(h5, 'iso1', 'benzene', 2.75, 3.3, rmbkg=True)

iso.addref('cal3', 'benzene', 78, 80, 7, 78, 78)
iso.addref('cal3', 'cyclohexane', 78, 80, 12, 84, 85)

iso.fit()
iso.save()

iso2 = Isotope(h5, 'iso1', 'phenol', 14.3, 15.5, rmbkg=True)

iso2.addref('cal6', 'phenol', 94, 96, 7, 94, 94)

iso2.fit()
iso2.save()

h5.compress()
h5.close()

